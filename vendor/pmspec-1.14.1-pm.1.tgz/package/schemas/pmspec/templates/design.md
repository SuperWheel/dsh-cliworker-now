# Design

<!-- // pmspec: decisions are machine-readable by pmspec decisions. -->
## Context

<!-- 引用 proposal / PRD，说明实现约束。 -->

## Goals / Non-Goals

## Decisions

### 决定 1：<事项>
- 最终决定：…
- 放弃的方案：… —— 原因：…
- 影响：…

## Risks / Trade-offs

## Migration Plan

# Tasks

<!-- // pmspec: two-level work packages; evidence is a plain indented bullet. -->
## 1. 功能或工作包 〔后端｜6h〕
- [ ] 1.1 实现并验证功能
  - 证据：完成后填写真实命令、结果或交付物
- [ ] 1.2 验收该功能（未执行：等待环境）

## 2. 设置页 〔前端｜8h｜前置 1〕
- [ ] 2.1 实现并验证设置页

## 跟进
- 复盘截止与归档后观察项

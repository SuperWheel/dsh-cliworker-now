# pmspec 分叉登记

<!-- // pmspec: per-file fork ledger required by PMSPEC §0. -->

上游基线：**OpenSpec v1.14.1 / 87c3595**（完整 SHA `87c3595ace6a2e22957f39ebe5b74c2f2316e0cb`）。MIT；`LICENSE` 保留原版权声明，内容未修改。分叉版本：`1.14.1-pm.3`，`private: true`。设计依据为同目录 `PMSPEC.md` 第 1～8 节。

## 行为与取舍

- 内部 OpenSpec 模块、类型和现有 `openspec/`、全局配置目录保留；对外包、二进制、生成技能与命令使用 pmspec。不同工具的命令都采用扁平 `pmspec-<workflow>` 前缀。
- 完整名称中的主题与创建人都允许横线，无法唯一分割。优先采用匹配的显式/默认创建人后缀；无默认值时取最后一段。建议用 `--version --topic --creator` 避免歧义。拼名缺创建人时给 whoami 指引。
- 旧名称、旧分组格式、默认无证据、pm 未知键等兼容性警告不因 `--strict` 升为错误；结构和类型错误仍失败。缩进复选框从进度中排除，strict 和 archive 拒绝；旧底层 Markdown 行扫描器保留以兼容诊断和定位。
- 新项目默认 schema 为 pmspec，现有未标记变更的上游 schema 推断保留。初始化保留空的 `changes/archive/` 兼容锚点，同时创建 `archives/`；doctor 仅在旧目录有实际归档时提示迁移。
- 读同名变更时依次选择活动目录、新归档、旧归档。新归档不加日期；目标存在即拒绝。迁移日期后缀仍冲突时整批预检失败，不覆盖、不先移动前面的项目。无日期前缀的旧归档不迁移。
- `tasks`、`decisions`、rename、migrate 在非 JSON 模式也输出同一 JSON，避免引入额外面板输出协议。`archivedPath` 使用已解析的绝对路径，与上游 `path` 字段一致。
- 归档日期写入使用原 YAML 文档保留未知键与注释，并原子替换；规格合并路径的写入在事务回滚范围内，纯移动路径在写入失败时移回。
- 遥测模块不读写配置、不生成 ID、不发送事件；版本查询固定 disabled，网络 fetch 空实现。保留上游本地安装检测/升级辅助函数，但禁用的版本检查不会触发升级提示或网络。
- 未提供面板公开下载 URL，因此 README 使用明确的本地 tarball 占位路径，不编造地址。Copilot 云端生成配置使用项目 lockfile 安装其已有 pmspec 依赖，不安装官方 openspec 代替。
- 原副本缺少上游测试读取的部分 docs-lab、website、fixtures、flake 与 specs 文件；从完整同一 commit 恢复后运行原测试，而非跳过断言。下表逐项区分未改动恢复与分叉修改。

## 版本记录

- `1.14.1-pm.3`（2026-11-13）：变更名的版本段保留点号（`v0.8.10-<主题>-<创建人>`），`new change` 与 `change rename` 一律生成带点的名字；旧的横线名（`v0-8-10-…`）仍算 pmspec 命名，不报警告，改名时换成带点的版本段。创建时的 kebab 校验只对 pmspec 名放行版本段的点。
- `1.14.1-pm.2`（2026-11-13）：主任务编号接受一个小写字母后缀（`## 1b.`，子任务 `1b.1`），旧变更插入的分组不再被改号、误报重复。
- `1.14.1-pm.1`（2026-11-13）：首个分叉版本。

## 文件登记

此表以任务开始时的磁盘副本为比较基准；未列 `PMSPEC.md`（用户设计稿）、依赖、构建输出和忽略的 tgz。`FORK.md` 本身为新增登记文件。代码用 `// pmspec:` 标注，Markdown/YAML 用各自合法注释；JSON 包配置使用 `"// pmspec:"` 字段。上游原样恢复的文件不插入注释，以保留基线字节。

| 文件 | 操作 | 原因 |
| --- | --- | --- |
| `README.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `bin/openspec.js` | 移除 | 替换为 pmspec 同名技能目录或可执行入口，不保留 openspec 二进制。 |
| `bin/pmspec.js` | 新增/补齐 | 私有包 pmspec@1.14.1-pm.3，唯一 pmspec 可执行入口与打包清单。 |
| `docs-lab/Notes.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/README.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/customize/overview.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/customize/profiles.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/customize/project-config.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/customize/schemas.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/customize/skills.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/guides/apply.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `docs-lab/guides/change-course.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/guides/concepts.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `docs-lab/guides/examples.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `docs-lab/guides/existing-codebases.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `docs-lab/guides/explore.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `docs-lab/guides/review-the-plan.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/guides/teams.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `docs-lab/help/faq.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `docs-lab/help/legacy/migration.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `docs-lab/help/troubleshooting.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `docs-lab/message-map.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/multi-repo/stores.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/multi-repo/worksets.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/reference/architecture/design-decisions.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `docs-lab/reference/architecture/index.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `docs-lab/reference/architecture/workflow-runs.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `docs-lab/reference/cli.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/reference/configuration/change-metadata.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/reference/configuration/config-json.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/reference/configuration/config-yaml.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/reference/configuration/environment-variables.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `docs-lab/reference/configuration/index.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/reference/configuration/stores.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `docs-lab/reference/glossary.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/reference/schemas/index.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/reference/schemas/schema-yaml.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/reference/schemas/spec-driven/index.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/reference/skills.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/reference/supported-tools.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/sources.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `docs-lab/start/installation.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/start/overview.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `docs-lab/start/quickstart.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs-lab/start/setup.md` | 新增/补齐 | 从相同上游 commit 补齐文档，再同步 pmspec 命令或归档说明。 |
| `docs/README.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/agent-contract.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/cli.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/commands.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/concepts.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/customization.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/editing-changes.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/examples.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/existing-projects.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/explore.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/faq.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/getting-started.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/glossary.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/how-commands-work.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/installation.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/migration-guide.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/multi-language.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/opsx.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/overview.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/reviewing-changes.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/stores-beta/user-guide.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/supported-tools.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/team-workflow.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/troubleshooting.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/workflows.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `docs/writing-specs.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `flake.nix` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/ai-tool-paths/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/artifact-graph/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/change-creation/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/ci-nix-validation/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/cli-archive/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/cli-artifact-workflow/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/cli-change/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/cli-completion/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/cli-config/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/cli-feedback/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/cli-init/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/cli-list/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/cli-show/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/cli-spec/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/cli-update/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/cli-validate/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/cli-view/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/command-generation/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/config-loading/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/context-injection/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/docs-agent-instructions/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/global-config/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/instruction-loader/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/legacy-cleanup/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/openspec-conventions/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/opsx-archive-skill/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/opsx-onboard-skill/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/opsx-verify-skill/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/rules-injection/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/schema-fork-command/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/schema-init-command/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/schema-resolution/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/schema-validate-command/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/schema-which-command/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/specs-sync-skill/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `openspec/specs/telemetry/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `package.json` | 修改 | 私有包 pmspec@1.14.1-pm.3，唯一 pmspec 可执行入口与打包清单。 |
| `schemas/pmspec/schema.yaml` | 新增/补齐 | 从 spec-driven 复制的 pmspec schema、模板与 instruction。 |
| `schemas/pmspec/templates/design.md` | 新增/补齐 | 从 spec-driven 复制的 pmspec schema、模板与 instruction。 |
| `schemas/pmspec/templates/proposal.md` | 新增/补齐 | 从 spec-driven 复制的 pmspec schema、模板与 instruction。 |
| `schemas/pmspec/templates/spec.md` | 新增/补齐 | 从 spec-driven 复制的 pmspec schema、模板与 instruction。 |
| `schemas/pmspec/templates/tasks.md` | 新增/补齐 | 从 spec-driven 复制的 pmspec schema、模板与 instruction。 |
| `schemas/spec-driven/schema.yaml` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `schemas/spec-driven/templates/proposal.md` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `scripts/generate-skillssh.mjs` | 修改 | 技能生成与快照键名适配 pmspec。 |
| `scripts/pack-version-check.mjs` | 修改 | 遥测空实现、版本查询永久禁用，保留本地版本与安装识别。 |
| `scripts/parity-hash-shared.mjs` | 修改 | 技能生成与快照键名适配 pmspec。 |
| `scripts/skillssh-shared.mjs` | 修改 | 技能生成与快照键名适配 pmspec。 |
| `scripts/update-flake.sh` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `skills/README.md` | 修改 | 分叉说明、使用方式及公开命令名称。 |
| `skills/openspec-apply-change/SKILL.md` | 移除 | 替换为 pmspec 同名技能目录或可执行入口，不保留 openspec 二进制。 |
| `skills/openspec-archive-change/SKILL.md` | 移除 | 替换为 pmspec 同名技能目录或可执行入口，不保留 openspec 二进制。 |
| `skills/openspec-bulk-archive-change/SKILL.md` | 移除 | 替换为 pmspec 同名技能目录或可执行入口，不保留 openspec 二进制。 |
| `skills/openspec-continue-change/SKILL.md` | 移除 | 替换为 pmspec 同名技能目录或可执行入口，不保留 openspec 二进制。 |
| `skills/openspec-explore/SKILL.md` | 移除 | 替换为 pmspec 同名技能目录或可执行入口，不保留 openspec 二进制。 |
| `skills/openspec-ff-change/SKILL.md` | 移除 | 替换为 pmspec 同名技能目录或可执行入口，不保留 openspec 二进制。 |
| `skills/openspec-new-change/SKILL.md` | 移除 | 替换为 pmspec 同名技能目录或可执行入口，不保留 openspec 二进制。 |
| `skills/openspec-onboard/SKILL.md` | 移除 | 替换为 pmspec 同名技能目录或可执行入口，不保留 openspec 二进制。 |
| `skills/openspec-propose/SKILL.md` | 移除 | 替换为 pmspec 同名技能目录或可执行入口，不保留 openspec 二进制。 |
| `skills/openspec-sync-specs/SKILL.md` | 移除 | 替换为 pmspec 同名技能目录或可执行入口，不保留 openspec 二进制。 |
| `skills/openspec-update-change/SKILL.md` | 移除 | 替换为 pmspec 同名技能目录或可执行入口，不保留 openspec 二进制。 |
| `skills/openspec-verify-change/SKILL.md` | 移除 | 替换为 pmspec 同名技能目录或可执行入口，不保留 openspec 二进制。 |
| `skills/pmspec-apply-change/SKILL.md` | 新增/补齐 | 由修改后的源模板重新生成 pmspec 技能。 |
| `skills/pmspec-archive-change/SKILL.md` | 新增/补齐 | 由修改后的源模板重新生成 pmspec 技能。 |
| `skills/pmspec-bulk-archive-change/SKILL.md` | 新增/补齐 | 由修改后的源模板重新生成 pmspec 技能。 |
| `skills/pmspec-continue-change/SKILL.md` | 新增/补齐 | 由修改后的源模板重新生成 pmspec 技能。 |
| `skills/pmspec-explore/SKILL.md` | 新增/补齐 | 由修改后的源模板重新生成 pmspec 技能。 |
| `skills/pmspec-ff-change/SKILL.md` | 新增/补齐 | 由修改后的源模板重新生成 pmspec 技能。 |
| `skills/pmspec-new-change/SKILL.md` | 新增/补齐 | 由修改后的源模板重新生成 pmspec 技能。 |
| `skills/pmspec-onboard/SKILL.md` | 新增/补齐 | 由修改后的源模板重新生成 pmspec 技能。 |
| `skills/pmspec-propose/SKILL.md` | 新增/补齐 | 由修改后的源模板重新生成 pmspec 技能。 |
| `skills/pmspec-sync-specs/SKILL.md` | 新增/补齐 | 由修改后的源模板重新生成 pmspec 技能。 |
| `skills/pmspec-update-change/SKILL.md` | 新增/补齐 | 由修改后的源模板重新生成 pmspec 技能。 |
| `skills/pmspec-verify-change/SKILL.md` | 新增/补齐 | 由修改后的源模板重新生成 pmspec 技能。 |
| `src/cli/commands/spec.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/cli/commands/store.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/cli/commands/workset.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/cli/index.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/commands/change.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/commands/completion.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/commands/config.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/commands/context.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/commands/doctor.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/commands/pmspec.ts` | 新增/补齐 | 新增 PMSPEC 命名、任务/决定、元数据校验及归档迁移实现。 |
| `src/commands/schema.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/commands/show.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/commands/store.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/commands/validate.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/commands/workflow/default-schema.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/commands/workflow/instructions.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/commands/workflow/new-change.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/commands/workflow/shared.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/commands/workflow/status.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/commands/workset-input.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/commands/workset.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/archive.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/artifact-graph/instruction-loader.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/artifact-graph/schema.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/change-metadata/schema.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/change-status-policy.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/command-generation/adapters/amazon-q.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/antigravity.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/atomcode.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/auggie.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/bob.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/claude.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/cline.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/codeassistant.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/codebuddy.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/codestudio.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/command-code.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/continue.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/costrict.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/crush.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/cursor.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/devin.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/easycode.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/factory.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/gemini.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/gigacode.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/github-copilot.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/iflow.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/junie.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/kilocode.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/kiro.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/lingma.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/oh-my-pi.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/opencode.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/pi.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/qoder.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/qwen.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/roocode.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/trae.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/adapters/zcode.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/generator.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/invocation.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/command-generation/types.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/completion-tip.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/completions/command-registry.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/completions/completion-provider.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/completions/generators/fish-generator.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/completions/generators/powershell-generator.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/completions/generators/zsh-generator.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/completions/templates/bash-templates.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/completions/templates/fish-templates.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/completions/templates/powershell-templates.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/completions/templates/zsh-templates.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/core/config-schema.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/config.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/github-copilot/cloud-agent.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/global-config.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/init.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/legacy-cleanup.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/list.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/migration.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/onboarding-commands.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/openspec-root.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/planning-home.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/profile-sync-drift.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/project-config.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/references.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/relationship-health.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/root-selection.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/shared-skill-target.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/shared/allowed-tools.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/shared/skill-content-equivalence.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/shared/skill-generation.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/shared/tool-detection.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/specs-apply.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/store/operations.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/store/registry.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/templates/optional-workflow.ts` | 修改 | 改为 pmspec 技能/命令、命名流程和无日期归档；保留上游内部符号。 |
| `src/core/templates/workflows/apply-change.ts` | 修改 | 改为 pmspec 技能/命令、命名流程和无日期归档；保留上游内部符号。 |
| `src/core/templates/workflows/archive-change.ts` | 修改 | 改为 pmspec 技能/命令、命名流程和无日期归档；保留上游内部符号。 |
| `src/core/templates/workflows/bulk-archive-change.ts` | 修改 | 改为 pmspec 技能/命令、命名流程和无日期归档；保留上游内部符号。 |
| `src/core/templates/workflows/continue-change.ts` | 修改 | 改为 pmspec 技能/命令、命名流程和无日期归档；保留上游内部符号。 |
| `src/core/templates/workflows/explore.ts` | 修改 | 改为 pmspec 技能/命令、命名流程和无日期归档；保留上游内部符号。 |
| `src/core/templates/workflows/feedback.ts` | 修改 | 改为 pmspec 技能/命令、命名流程和无日期归档；保留上游内部符号。 |
| `src/core/templates/workflows/ff-change.ts` | 修改 | 改为 pmspec 技能/命令、命名流程和无日期归档；保留上游内部符号。 |
| `src/core/templates/workflows/new-change.ts` | 修改 | 改为 pmspec 技能/命令、命名流程和无日期归档；保留上游内部符号。 |
| `src/core/templates/workflows/onboard.ts` | 修改 | 改为 pmspec 技能/命令、命名流程和无日期归档；保留上游内部符号。 |
| `src/core/templates/workflows/project-root.ts` | 修改 | 改为 pmspec 技能/命令、命名流程和无日期归档；保留上游内部符号。 |
| `src/core/templates/workflows/propose.ts` | 修改 | 改为 pmspec 技能/命令、命名流程和无日期归档；保留上游内部符号。 |
| `src/core/templates/workflows/store-selection.ts` | 修改 | 改为 pmspec 技能/命令、命名流程和无日期归档；保留上游内部符号。 |
| `src/core/templates/workflows/sync-specs.ts` | 修改 | 改为 pmspec 技能/命令、命名流程和无日期归档；保留上游内部符号。 |
| `src/core/templates/workflows/update-change.ts` | 修改 | 改为 pmspec 技能/命令、命名流程和无日期归档；保留上游内部符号。 |
| `src/core/templates/workflows/verify-change.ts` | 修改 | 改为 pmspec 技能/命令、命名流程和无日期归档；保留上游内部符号。 |
| `src/core/update.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/validation/constants.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/validation/task-checkboxes.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/validation/types.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/validation/validator.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/version-check.ts` | 修改 | 遥测空实现、版本查询永久禁用，保留本地版本与安装识别。 |
| `src/core/view.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/core/worksets.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/telemetry/index.ts` | 修改 | 遥测空实现、版本查询永久禁用，保留本地版本与安装识别。 |
| `src/ui/welcome-screen.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/utils/change-metadata.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/utils/change-utils.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称；创建校验放行带点版本段的 pmspec 名。 |
| `src/utils/command-references.ts` | 修改 | 公开命令 pmspec 前缀、新子命令和补全参数。 |
| `src/utils/interactive.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/utils/item-discovery.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/utils/nested-change.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `src/utils/pmspec-archives.ts` | 新增/补齐 | 新增 PMSPEC 命名、任务/决定、元数据校验及归档迁移实现。 |
| `src/utils/pmspec-names.ts` | 新增/补齐 | 新增 PMSPEC 命名、任务/决定、元数据校验及归档迁移实现。 |
| `src/utils/pmspec-tasks.ts` | 新增/补齐 | 新增 PMSPEC 命名、任务/决定、元数据校验及归档迁移实现。 |
| `src/utils/pmspec-validation.ts` | 新增/补齐 | 新增 PMSPEC 命名、任务/决定、元数据校验及归档迁移实现。 |
| `src/utils/task-progress.ts` | 修改 | 接入 pmspec 默认 schema、pm 元数据、任务进度、双位置归档或公开命令名称。 |
| `test/apply-docs-claims.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/cli-e2e/archive-closed-requirement-heading.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/cli-e2e/archive-requirement-name-near-miss.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/cli-e2e/basic.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/cli-e2e/capstone-journeys.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/cli-e2e/completion-tip.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/cli-e2e/startup-modules.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/cli-e2e/store-lifecycle.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/cli-e2e/validate-archived-tasks.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/cli-e2e/validate-findings.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/cli-e2e/validate-scenario-loss.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/cli-e2e/validate-task-checkboxes.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/cli-e2e/validate-task-numbering.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/cli-e2e/view-store-resolution.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/apply-instructions-blocked.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/apply-instructions-tasks.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/apply-instructions-warnings.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/artifact-workflow.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/change-initiative-link.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/change.interactive-show.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/change.interactive-validate.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/config-edit.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/config-profile.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/context.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/declared-store-fallback.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/doctor.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/global-default-store.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/legacy-groups-removed.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/profile-handoffs.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/schema-apply-references.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/schema-fork-fidelity.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/schema.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/schemas.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/show-diff.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/show.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/spec.interactive-show.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/spec.interactive-validate.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/spec.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/status-all.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/store-git.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/store-phantom-root.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/store-references.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/store-remote.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/store-remove-nested.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/store-root-selection.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/store.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/validate.enriched-output.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/validate.findings.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/validate.name-guard.security.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/validate.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/commands/workset.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/archive.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/artifact-graph/schema-apply-references.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/available-tools.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/change-status-policy.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/cli-is-json-run.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/command-generation/adapters.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/command-generation/generator.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/command-generation/invocation.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/command-generation/types.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/commands/change-command.list.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/commands/change-command.show-validate.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/completion-tip.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/completions/command-registry.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/completions/completion-provider.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/completions/generators/bash-generator.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/completions/generators/fish-generator.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/completions/generators/powershell-generator.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/completions/generators/zsh-generator.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/completions/installers/bash-installer.round-trip.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/completions/installers/bash-installer.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/completions/installers/fish-installer.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/completions/installers/powershell-installer.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/completions/installers/zsh-installer.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/converters/json-converter.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/github-copilot-cloud-agent.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/global-config.unparseable.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/init.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/legacy-cleanup.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/legacy-cleanup.user-files.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/list.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/migration.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/misplaced-delta-files.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/onboarding-commands.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/openspec-root.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/parsers/change-parser-delta-agreement.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/profile-sync-drift.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/project-config.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/purpose-placeholder.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/references.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/root-selection.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/shared-skill-target.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/shared/generated-by-scan.security.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/shared/profile-workflow-references.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/shared/skill-content-equivalence.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/shared/skill-generation.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/shared/tool-detection-command-drift.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/shared/tool-detection.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/specs-apply.comment-masking.security.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/specs-apply.symlink-escape.security.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/templates/archive-task-progress.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/templates/bulk-archive-existing-target.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/templates/explore.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/templates/list-json-contract.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/templates/main-spec-paths.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/templates/optional-workflow.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/templates/profile-handoffs.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/templates/project-root-guard.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/templates/propose.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/templates/requirement-length-guidance.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/templates/skill-templates-parity.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/templates/spec-inventory.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/templates/update-change.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/templates/verify-change-delta-operations.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/templates/workflow-verb-triggers.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/tool-search-aliases.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/update-skill-tamper.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/update.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/validation.purpose-placeholder.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/validation.scenario-body-parity.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/version-check.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/view.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/warp.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/working-set.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/core/worksets.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/explore-docs-claims.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/fixtures/tmp-init/openspec/changes/c1/proposal.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `test/fixtures/tmp-init/openspec/changes/c1/specs/alpha/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `test/fixtures/tmp-init/openspec/specs/alpha/spec.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `test/helpers/run-cli.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/init-store-docs-claims.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/pmspec.test.ts` | 新增/补齐 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/setup-docs-claims.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/skills-docs-claims.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/telemetry/index.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/ui/welcome-screen.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/utils/change-utils.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/utils/command-references.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/utils/item-discovery.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/utils/marker-updates.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/utils/path-containment.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/utils/task-progress.list-markers.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `test/utils/task-progress.test.ts` | 修改 | 更新分叉名称、默认 schema、归档路径、两级进度的断言，保留原场景。 |
| `website/.gitignore` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/README.md` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/app/api/search/route.ts` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/app/docs/[[...slug]]/page.tsx` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/app/docs/layout.tsx` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/app/global.css` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/app/icon.svg` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/app/layout.tsx` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/app/llms-full.txt/route.ts` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/app/llms.mdx/docs/[[...slug]]/route.ts` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/app/llms.txt/route.ts` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/app/og/docs/[...slug]/route.tsx` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/app/page.tsx` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/app/robots.ts` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/app/sitemap.ts` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/cloudflare/router/worker.js` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/cloudflare/router/wrangler.jsonc` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/components/file-steps.tsx` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/components/mdx.tsx` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/components/mermaid.tsx` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/components/provider.tsx` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/components/search.tsx` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/docs.sync.config.mjs` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/lib/layout.shared.tsx` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/lib/remark-faq.ts` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/lib/remark-file-steps.ts` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/lib/remark-gfm-alert.ts` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/lib/shared.ts` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/lib/source.ts` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/next.config.mjs` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/package.json` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/pnpm-lock.yaml` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/pnpm-workspace.yaml` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/postcss.config.mjs` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/public/_redirects` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/public/openspec-pixel.svg` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/scripts/sync-docs.mjs` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/source.config.ts` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
| `website/tsconfig.json` | 新增/补齐 | 从相同上游 commit 补齐原副本缺失的回归依赖；未修改内容。 |
